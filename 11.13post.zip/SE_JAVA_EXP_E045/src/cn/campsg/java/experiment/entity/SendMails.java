package cn.campsg.java.experiment.entity;

public class SendMails extends Thread {
	public SendMails() {
		super();
	}

	private Postman post;

	public Postman getPost() {
		return post;
	}

	public void setPost(Postman post) {
		this.post = post;
	}
	public void run() {
		int count=0;
		while(post.getMailCount()>0) {
			System.out.println(post.getPostName()+"����"+post.getMailCount()+ "���š���ʼ�͵� " + (++count) + "���ţ�");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			post.setMailCount(post.getMailCount()-1);
			if(post.getMailCount()<=0) {
				System.out.println(post.getPostName()+" ����������ʼ�����!");
			}
			
		}
		
			
		
	}
}

