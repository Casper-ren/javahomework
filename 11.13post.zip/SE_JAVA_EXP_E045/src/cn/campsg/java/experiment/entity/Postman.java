package cn.campsg.java.experiment.entity;

public class Postman {
	/**
	 * @param postName
	 * @param mailCount
	 */
	public Postman() {
		super();
	}
	public Postman(String postName, int mailCount) {
		super();
		this.postName = postName;
		this.mailCount = mailCount;
	}
	private String postName;
    private int mailCount;
	public String getPostName() {
		return postName;
	}
	public void setPostName(String postName) {
		this.postName = postName;
	}
	public int getMailCount() {
		return mailCount;
	}
	public void setMailCount(int mailCount) {
		this.mailCount = mailCount;
	}
    

}
