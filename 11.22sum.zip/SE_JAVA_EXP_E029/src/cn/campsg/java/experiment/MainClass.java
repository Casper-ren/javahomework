package cn.campsg.java.experiment;

public class MainClass {
	public static int sum(String numberStr) {
		
		String[] arr=numberStr.split(";");
		int sum=0;
		for(int i=0;i<arr.length;i++) {
			
			String a=arr[i].substring(arr[i].length()-1,arr[i].length());
			int b=Integer.valueOf(a);
			sum=sum+b;
		}
		
		
		
		return sum;
	  }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="105;20;30;40;50;55;26;7";
		int a=sum(str);
		System.out.println("ԭ�ַ����У�"+str);
		System.out.println("���и�λ����ͽ����" +a);
		
	}

}
