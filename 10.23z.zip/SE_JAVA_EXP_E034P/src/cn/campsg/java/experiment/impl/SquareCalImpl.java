package cn.campsg.java.experiment.impl;

import cn.campsg.java.experiment.ShapeCalc;

public class SquareCalImpl implements ShapeCalc {
	/**
	 * @param length
	 */
	public SquareCalImpl() {
		super();
	}

	private float length;
	@Override
	public float calcPerim() {
		// TODO Auto-generated method stub
		float peri = length * 4 ;
		return peri;
	}
	@Override
	public float calcArea() {
		// TODO Auto-generated method stub
		float area= length * length;
		return area;
	}

	public float getLength() {
		return length;
	}

	public void setLength(float length) {
		this.length = length;
	}

}
