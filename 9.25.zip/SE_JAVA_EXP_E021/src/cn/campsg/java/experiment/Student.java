package cn.campsg.java.experiment;

public class Student {
	/**
	 * @param name
	 * @param age
	 * @param sex
	 * @param score
	 */
	public Student() {
		this.name = "";
		this.age = 0;
		this.sex = true;
		this.score = 0.0f;
	}
	public Student(String name, int age, boolean sex, float score) {
		super();
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.score = score;
	}
	private String name;
	private int age;
	private boolean sex;
	private float score;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		if(age>18) {
			this.age = age;
		}
		else {
			this.age = 18;
		}
		
	}
	public String getSex() {
		if(sex==true) {
			return "��";
		}
		else {
			return "Ů";
		}
	}
	public void setSex(boolean sex) {
		this.sex = sex;
	}
	public float getScore() {
		return score;
	}
	public void setScore(float score) {
		this.score = score;
	}
}
