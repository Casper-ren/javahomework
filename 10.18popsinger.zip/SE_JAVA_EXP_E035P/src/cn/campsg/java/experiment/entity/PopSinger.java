package cn.campsg.java.experiment.entity;
public class PopSinger extends AbstractSinger {

	public void sing() {
		// TODO Auto-generated method stub
		System.out.println("���ǳ������ֵġ�");

	}

}
