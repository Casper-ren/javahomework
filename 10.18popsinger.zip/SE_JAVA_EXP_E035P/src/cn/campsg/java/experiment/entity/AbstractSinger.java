package cn.campsg.java.experiment.entity;

public abstract class AbstractSinger {
	public void introduce() {
		System.out.println("Hello�����Ǹ��֡�");
	}
	public abstract void sing(); 
}
