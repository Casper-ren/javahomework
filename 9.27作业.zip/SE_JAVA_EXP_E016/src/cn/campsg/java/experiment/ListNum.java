package cn.campsg.java.experiment;
import java.util.Scanner;
public class ListNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] Mylist=new int[5];
		int i;
		int j;
		int t;
		Scanner sc=new Scanner(System.in);
		for(i=0;i<5;i++) {
			System.out.println("�������"+(i+1)+"�����֣����س���");
			Mylist[i]=sc.nextInt();
		}
		sc.close();
		for(i=0;i<Mylist.length;i++)
		{
			for(j=i+1;j<Mylist.length;j++) {
				if(Mylist[i]>Mylist[j]) {
					t=Mylist[i];
					Mylist[i]=Mylist[j];
					Mylist[j]=t;
				}
			}
				
		}
		System.out.println("����������Ϊ��");
		for(i=0;i<Mylist.length;i++) {
			System.out.print(Mylist[i]+" ");
		}
	}
	
}
