package cn.campsg.java.experiment;

import cn.campsg.java.experiment.entity.Configuration;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Configuration cfg = new Configuration();
		String cfgName = "‪F:\\javaworkspace\\SE_JAVA_EXP_E043\\config.properties";

        cfg.loadConfiguration(cfgName);
        for(int i=0;i<6;i++){//模拟写入6项

            cfg.updateConfiguration("xKey-"+i, "xValue_"+i);

        }
        cfg.updateConfiguration("xKey-0", "杀手");
        for(int i=0;i<6;i++){ 

            System.out.println("配置信息："+"xKey-"+i+    "="+cfg.readCfgByKey("xKey-"+i));

        }
	}

}