package cn.campsg.java.experiment.entity;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;



public class Configuration {
		Properties config = null ;
		String cfgFile;
		public Configuration() {
		
		}
		
		public void loadConfiguration(String fullCfgFile) {
			try {	
				config = new Properties();
				cfgFile = fullCfgFile;
				FileInputStream in =null ;
				in=new FileInputStream(cfgFile);
				config.load(in);
				in.close();
				System.out.println("�ɹ����������ļ�:"+cfgFile);
		  }catch(FileNotFoundException e) {
			  System.out.println("��ȡ�ļ�����ʧ�ܣ�����ԭ��:�ļ�·����������ļ������ڣ�");
			  e.printStackTrace();
		  }catch (IOException e) {
			  System.out.println("װ���ļ�ʧ�ܣ�");
			  e.printStackTrace();
		}
		}
			
		
		
		public String readCfgByKey (String key) {
				if(config!=null) {
					return config.getProperty(key) ;
				}else {
					return null;
				}
		  }
		
		public void updateConfiguration(String key ,String value) {
			String val = readCfgByKey(key);
			if(val==null) {
				config.setProperty(key, value);
			}
			else {
				config.put(key, value);
			}
			FileOutputStream os=null;
			try {
				os = new FileOutputStream(cfgFile);
				config.store(os, "д����������Ϣ��");
				os.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
				
		  }
}