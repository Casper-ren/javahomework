package cn.campsg.java.experiment;
import cn.campsg.java.experiment.entity.*;
public class MainClass {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Zeus a=new Zeus();
		Taitan b=new Taitan();
		attack(a,b);
		}	
		  
public static void attack(Zeus zeus,Taitan taitan) {
	do {
		zeus.attack(taitan);
		if(taitan.getBlood()<=0)
		{
			System.out.println("̩̹��������˹��ʤ");
		}
		taitan.attack(zeus);
		if(zeus.getBlood()<=0)
		{
			System.out.println("��˹������̩̹��ʤ");
		}
		}while((zeus.getBlood()>0) & (taitan.getBlood()>0));

	
	
	}
}

