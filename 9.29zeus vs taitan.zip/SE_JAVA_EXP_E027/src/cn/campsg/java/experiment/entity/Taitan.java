package cn.campsg.java.experiment.entity;
import java.util.Random;
public class Taitan {
	private int blood=700;

	public int getBlood() {
		return blood;
	}

	public void setBlood(int blood) {
		this.blood = blood;
	}
	public void attack(Zeus zeus) {
		Random random = new Random(); 
		int q=random.nextInt(101);
		zeus.setBlood(zeus.getBlood()-q);
		System.out.println("̩̹������˹����˹��Ѫ:" + q + ",ʣ�ࣺ" + zeus.getBlood());
	  }
	  
}
