package cn.campsg.java.experiment.entity;
import java.util.Random;
public class Zeus {
	private int blood=1000;

	public int getBlood() {
		return blood;
	}

	public void setBlood(int blood) {
		this.blood = blood;
	}
	public void attack(Taitan taitan) {
		Random random = new Random(); 
		int q=random.nextInt(70);
		taitan.setBlood(taitan.getBlood()-q);
		System.out.println("��˹����̩̹��̩̹��Ѫ:" + q + ",ʣ�ࣺ" + taitan.getBlood());
	  }
}