package cn.campsg.java.experiment.entity;

public class Producer implements Runnable {
	private SharePool pool;
	private int count;
	public Producer() {
		
	}
	public  Producer(SharePool  pool,int num) {
        this.pool = pool ;
        this.count = num ;
	}
	public void run() {  
		String media="������־";
		int counter=0;
		System.out.println("������@"+Thread.currentThread().getName()+"������"+count+"�ݡ�");
		for(int i=0;i<count;i++) {
			if(count<=0) {
				System.out.println("������@"+Thread.currentThread().getName()+"->��ɶ��ġ�");
				break;
			}
			count++;
			System.out.println("������@"+Thread.currentThread().getName()+" ���ύ��"+counter+" �ݶ������롣");
			try {
				pool.produce(media+counter);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            count--;
            try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
