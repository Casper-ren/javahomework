package cn.campsg.java.experiment;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

import cn.campsg.java.experiment.service.AskClient;

public class Clients {

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
		String srvIP = "127.0.0.1";
		int srvPort = 9999;
				
		Socket socket1 = new Socket(srvIP,srvPort);
		Socket socket2 = new Socket(srvIP,srvPort);
		Socket socket3 = new Socket(srvIP,srvPort);
		Socket socket4 = new Socket(srvIP,srvPort);
		new Thread(new AskClient(socket1,"CA1893"),"��ѯ��@CA1893").start();
		new Thread(new AskClient(socket2,"CZ3590"),"��ѯ��@CZ3590").start();
		new Thread(new AskClient(socket3,"FM9802"),"��ѯ��@FM9802").start();
		new Thread(new AskClient(socket4,"XS9882"),"��ѯ��@XS9882").start();
	}

}
