package cn.campsg.java.experiment.impl;

import cn.campsg.java.experiment.SeekJob;

public class SoftwareSeeker implements SeekJob {
	/**
	 * @param name
	 * @param scores
	 */
	public SoftwareSeeker(String name, float[] scores) {
		super();
		this.name = name;
		this.scores = scores;
	}
	public SoftwareSeeker() {
		super();
	}
	private String name;
	private float[] scores = null;
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public float getSeekerAverage() {
		// TODO Auto-generated method stub
		float average;
		average = scores[0] * 0.6f+scores[1]*0.4f;
		return average;
	}

	public float[] getScores() {
		return scores;
	}

	public void setScores(float[] scores) {
		this.scores = scores;
	}

	public void setName(String name) {
		this.name = name;
	}


}
