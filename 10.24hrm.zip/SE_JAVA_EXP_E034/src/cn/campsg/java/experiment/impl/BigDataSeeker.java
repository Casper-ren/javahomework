package cn.campsg.java.experiment.impl;

import cn.campsg.java.experiment.SeekJob;

public class BigDataSeeker implements SeekJob {
	/**
	 * @param name
	 * @param scores
	 */
	public BigDataSeeker(String name, float[] scores) {
		super();
		this.name = name;
		this.scores = scores;
	}
	public BigDataSeeker() {
		super();
	}

	private String name;
	private float[] scores = null ;
	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return name;
	}

	@Override
	public float getSeekerAverage() {
		// TODO Auto-generated method stub
		float average;
		average =(scores[0]+scores[1])/2;
		return average;
	}

	public float[] getScores() {
		return scores;
	}

	public void setScores(float[] scores) {
		this.scores = scores;
	}

	public void setName(String name) {
		this.name = name;
	}

}
