package cn.campsg.java.experiment;

public interface SeekJob {
	public float SEEKER_AVERAGE_SCORE=85.0f;
	public String getName() ;
	public float getSeekerAverage();
}
