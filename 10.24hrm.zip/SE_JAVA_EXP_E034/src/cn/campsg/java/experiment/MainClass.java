package cn.campsg.java.experiment;

import cn.campsg.java.experiment.impl.BigDataSeeker;
import cn.campsg.java.experiment.impl.SoftwareSeeker;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 SoftwareSeeker soft1 = new SoftwareSeeker("��С��",new float[]{10.0f,100.0f});
		 SoftwareSeeker soft2 = new SoftwareSeeker("��С��",new float[]{80.0f,100.0f});

		 BigDataSeeker bdata1 = new BigDataSeeker("�����",new float[]{10.0f,100.0f});
		 BigDataSeeker bdata2 = new BigDataSeeker("�����",new float[]{80.0f,100.0f});
		 HrMarketer hr=new HrMarketer();
		 System.out.println(hr.seekJob(soft1));
		 System.out.println(hr.seekJob(soft2));
		 System.out.println(hr.seekJob(bdata1));
		 System.out.println(hr.seekJob(bdata2));

	}

}
