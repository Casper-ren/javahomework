package cn.campsg.java.experiment;

public class Employee {
	/**
	 * @param no
	 * @param name
	 * @param salary
	 * @param department
	 */
	public Employee() {
		
	}
	public Employee(String no, String name, float salary, String department) {
		super();
		this.no = no;
		this.name = name;
		this.salary = salary;
		this.department = department;
	}
	String no;
	String name;
	float salary;
	String department;
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		if(obj==null) {
			return false;
		}
		if(!(obj instanceof Employee)) {
		    return false;
		}
		Employee emp = (Employee)obj;
		if(!emp.getNo().equals(this.getNo())) {
		    return false;
		}
		return true;
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		StringBuffer buffer=new StringBuffer();
		buffer.append("����: " + no + ",����: " + name  + ",����: " + department + ",нˮ: " + salary);
		return buffer.toString();
	}

}
