package cn.campsg.java.experiment;

public class MainClass {
	public static boolean isRepeat(int index,Employee[] employees) {
		Employee emp=employees[index];
		for(int i=0;i<employees.length;i++) {
			if(emp == employees[i]) 
				continue;
			if(emp.equals(employees[i])==true) 
				return true;
		}
		return false;
	}
				
			
		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0;
		Employee[] employees = new Employee[3];
		employees[0] = new Employee("1001","��һ",5000.0f,"���۲�");
		employees[1] = new Employee("1002","����",6500.0f,"���۲�");
		employees[2] = new Employee("1001","Alan",15000.0f,"�з���");
		for(int j=0;j<employees.length;j++) {
			if(!isRepeat(j,employees)) {
				System.out.println(employees[j].toString());
				count++;
			}
		}
		System.out.println("����˾��ЧԱ����: "  + count);
	}

}
