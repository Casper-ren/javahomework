
public class StrToInt {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a="1234";
		Integer.valueOf(a);
		System.out.println(a);

	}

}
