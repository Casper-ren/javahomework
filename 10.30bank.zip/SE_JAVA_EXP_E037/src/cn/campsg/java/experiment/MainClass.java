package cn.campsg.java.experiment;
import java.util.Scanner;

import cn.campsg.java.experiment.entity.Bank;
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long cash = 0L;
		 
		Scanner scanner = new Scanner(System.in);
		System.out.print("������ȡ���");
		 
		try {
		        cash = Long.parseLong(scanner.nextLine());
		} catch (NumberFormatException nfe) {
		        System.out.println("�������ȷ������������ȡ����.");
		        scanner.close();
		        return;
		}
		Bank bank=new Bank();
		try {
		     bank.withDraw(cash);
		} catch (InterruptedException ie) {
		      System.out.println(ie.getMessage());
		}
		scanner.close();
		
}}


