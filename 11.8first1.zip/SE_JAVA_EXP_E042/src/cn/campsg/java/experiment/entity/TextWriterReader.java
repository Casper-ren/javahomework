package cn.campsg.java.experiment.entity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

public class TextWriterReader {
	public TextWriterReader() {
		
	}
	public String readText(String fileLocation) throws IOException {
		StringBuffer text =new StringBuffer();
		File file =new File(fileLocation);
		if (file.isFile() && file.exists()) {
		    // ���ǵ������ʽ
		    InputStreamReader read = new InputStreamReader(new FileInputStream(file),"UTF-8");
		    BufferedReader bufferedReader = new BufferedReader(read);
		    String lineTxt = null;
		    while ((lineTxt = bufferedReader.readLine()) != null) { 
		       text.append(lineTxt).append("\n");
		    }
		    read.close();
		 }
		else {
			System.out.println("�Ҳ���ָ�����ı��ļ���");
		}
		return text.toString();
	}
	
	 public boolean writeText(String content,String fileLocation){
		 File file = new File(fileLocation);
		 boolean flag = false;
		 FileOutputStream fos=null;
		 try {
			fos = new FileOutputStream(file);
			byte[] srtbyte = content.getBytes();
			try {
				fos.write(srtbyte);
				fos.close();
				flag=true;
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return flag;

	  }
	
}
