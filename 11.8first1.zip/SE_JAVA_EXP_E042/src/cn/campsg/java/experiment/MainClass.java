package cn.campsg.java.experiment;

import java.io.IOException;

import cn.campsg.java.experiment.entity.TextWriterReader;

public class MainClass {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		TextWriterReader wr = new TextWriterReader();
		String txtFile = "mytext.txt";
		System.out.println(wr.readText(txtFile));
		wr.writeText("hellooo", txtFile);
		
	}

}
