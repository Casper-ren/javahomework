package cn.campsg.java.experiment;
import java.util.Scanner ;
public class RabbitNum {
	public static int rabbit(int month) {
		int thismonth=2;
		int lastmonth=2;
		int lastlastmonth=2;
		for(int i=1;i<month+1;i++) {
			if(i<3) {
				continue;
			}
			else {
				thismonth=lastmonth+lastlastmonth;
				lastlastmonth=lastmonth;
				lastmonth=thismonth;
			}
		}
		return thismonth;
	  }

	public static void main(String[] args) {
		// TODO Auto-generated method stub\
		System.out.println("���������ӷ�ֳ���·ݣ�");
		Scanner sc=new Scanner(System.in);
		int month=sc.nextInt();
		sc.close();
		int x=rabbit(month);
		System.out.println("��"+month+"���£����ӵ�������:"+x);
	}

}
