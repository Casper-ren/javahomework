import java.util.Arrays;
import java.util.Collections;
import java.util.List;



public class BinSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> intList = Arrays.asList(76,4,786,43,21,432,10);
		Collections.sort(intList);
		int re=Collections.binarySearch(intList, 10);
		System.out.println(re);
	}

}
