package cn.campsg.java.experiment.exception;

public class RoseException extends Exception{
	 public RoseException(){
	 }
	 public RoseException(String msg){
		 super(msg);
	 }

}
