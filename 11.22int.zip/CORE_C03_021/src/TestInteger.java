
public class TestInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer i=new Integer(123);
		i.intValue();
		i++;
		Integer y=new Integer(i);
		System.out.println("y="+y);
	}

}
