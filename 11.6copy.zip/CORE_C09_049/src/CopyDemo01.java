import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDemo01 {
	public static void copyImageFile(String s1,String s2) {
		try{
			BufferedInputStream bufferedInput = new BufferedInputStream(new FileInputStream(s1));
			BufferedOutputStream bufferedOutput=new BufferedOutputStream(new FileOutputStream(s2));
			byte[] b =new byte[2048];
			int len=bufferedInput.read(b);
			while(len!=-1) {
				bufferedOutput.write(b);
				len=bufferedInput.read(b);
			}
			
			bufferedOutput.close();
			bufferedInput.close();
			
		}
		catch(FileNotFoundException e) {
			e.getStackTrace();
			
		}
		catch(IOException e) {
			e.getStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		copyImageFile("icon.png","copyIcon.png");
	}

}
