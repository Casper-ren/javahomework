import java.util.ArrayList;
import java.util.List;

public class Bubble {
	public static void bubble(List<Integer> a) {
		int i=0;
		int j=0;
		int temp;
		for(i=0;i<a.size();i++) {
			for(j=i+1;j<a.size();j++){
				if ((a.get(i)).compareTo(a.get(j))>0) {
					temp=a.get(i);
					a.set(i,a.get(j));
					a.set(j,temp);
				}
		}
		}
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> a= new ArrayList<Integer>();
		a.add(76);
		a.add(4);
		a.add(786);
		a.add(43);
		a.add(21);
		a.add(432);
		a.add(10);
		bubble(a);
		for(int i=0;i<a.size();i++) {
			System.out.println(a.get(i));
		}
	}

}
