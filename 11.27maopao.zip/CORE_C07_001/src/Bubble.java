
public class Bubble {
	public static void bubble(Integer[] a) {
		int i=0;
		int j=0;
		int temp;
		for(i=0;i<a.length;i++) {
			for(j=i+1;j<a.length;j++){
				if (a[i].compareTo(a[j])>0) {
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
		}
		}
		for(i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer a[]= {76,4,786,43,21,432,10};
		bubble(a);
	}

}
