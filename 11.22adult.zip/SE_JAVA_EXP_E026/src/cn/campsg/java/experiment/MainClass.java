package cn.campsg.java.experiment;

public class MainClass {
	public static int[] getAges() {
		int[] ages = new int[200];
		for(int i=0;i<ages.length;i++) {
			int age = (int) (Math.random() * 61);
			ages[i]=age;
		}
		
		return ages;
		
		
		
	  }
	 public static int getAdultCount(int[] ages) {
		 int adult=0;
		 for(int i=0;i<ages.length;i++) {
			 if(ages[i]>=18) {
				 adult++;
			 }
		 }
		 return adult;
	  }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a=getAges();
		int b=getAdultCount(a);
		System.out.println("200���û��У�����"  + b + "��������");
	}

}
