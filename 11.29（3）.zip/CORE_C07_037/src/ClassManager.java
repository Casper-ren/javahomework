import java.util.HashMap;
import java.util.Iterator;

public class ClassManager {
	HashMap< String, Student> hMap = new HashMap< String, Student>();
	public void saveStudent(String s,Student st) {
		hMap.put(s, st);
		
	}
	public String checkAllStudent() {
		String re = "";
		Iterator<String> b=hMap.keySet().iterator();
		while(b.hasNext()) {
			String c=b.next();
			re=re+"ѧ��:"+c+","+hMap.get(c).toString()+"\n";
			
		}
		return re;
		
	}
	public static void main(String[] args) {
		ClassManager cm=new ClassManager();
		Student st1=new Student("Roger",21,true);
		Student st2=new Student("July",20,false);
		cm.saveStudent("115599", st1);
		cm.saveStudent("335577", st2);
		System.out.println(cm.checkAllStudent());
	}

}


