package cn.campsg.java.experiment;

import cn.campsg.java.experiment.entity.Employe;
import cn.campsg.java.experiment.entity.Hrstaff;

public class Company {
	 public void appraisals(Employe emp) {
		 emp.work();
		 if(emp instanceof Hrstaff) {
			 int level=emp.getLevel();
			 String str=((Hrstaff) emp).looupSalary(level);
			 System.out.println("HR�Ĺ�Ա�ȼ�Ϊ:"+level+","+str);
			 
			 
		 }
	  }
}
