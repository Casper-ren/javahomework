package cn.campsg.java.experiment;

import cn.campsg.java.experiment.entity.Employe;
import cn.campsg.java.experiment.entity.Hrstaff;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employe emm=new Employe("hr",5,5000);
		Hrstaff aff=new Hrstaff("HR");
		Company kp=new Company();
		kp.appraisals(emm);
		kp.appraisals(aff);
		
	}

}
