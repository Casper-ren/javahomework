package cn.campsg.java.experiment.entity;

public class Employe {
	/**
	 * @param name
	 * @param level
	 * @param salary
	 */
	public Employe() {
		super();
	}
	public Employe(String name, int level, int salary) {
		super();
		this.name = name;
		this.level = level;
		this.salary = salary;
	}
	String name;
	int level;
	int salary;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public void work() {
		System.out.println(name+"���쵼��Ҫ���������");
    }
}