package cn.campsg.java.experiment;

import java.util.ArrayList;
import java.util.List;


public class QueueCaller {
	private ArrayList<String> queue;
	public QueueCaller(){
		queue=new ArrayList<String>();
	  }
	public int size() {
		return queue.size();
	  }
	public void fetchNumber(String patient) {
		queue.add(patient);
		System.out.println(patient + "ǰ�滹�� " + (size() - 1)+ " λ�ڵȺ���");
	  }
	public void showPatients() {
		if(queue.isEmpty()) {
			return;
		}
		else {
			System.out.println(queue.get(0)+"������");
		}
		
	  }
	public void callNumber() {
		System.out.println("�뻼�ߣ�" + queue.get(0) + " �����Ҿ��");
		queue.remove(0);
	  }
	
	
	

}
