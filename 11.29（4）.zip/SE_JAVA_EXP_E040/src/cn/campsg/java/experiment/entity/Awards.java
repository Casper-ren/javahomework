package cn.campsg.java.experiment.entity;

public class Awards {
	/**
	 * @param name
	 * @param count
	 */
	public Awards(String name, int count) {
		super();
		this.name = name;
		this.count = count;
	}
	private String name;
	private int count;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public Awards(){

	  }
	

}