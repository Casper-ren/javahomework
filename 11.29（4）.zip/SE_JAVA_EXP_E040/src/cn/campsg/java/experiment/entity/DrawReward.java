package cn.campsg.java.experiment.entity;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class DrawReward {
	 HashMap<Integer, Awards> rwdPool = null;
	 public DrawReward (){
		 this.rwdPool = new HashMap<Integer, Awards>();
		 Awards a1=new Awards("�صȽ�",1);
		 Awards a2=new Awards("һ�Ƚ�",4);
		 Awards a3=new Awards("���Ƚ�",6);
		 Awards a4=new Awards("���Ƚ�",100);
		 this.rwdPool.put(8, a1);
		 this.rwdPool.put(1, a2);
		 this.rwdPool.put(2, a3);
		 this.rwdPool.put(0, a4);
	  }

	 
	 public void draward(int rdKey) {
		 Awards aw = this.rwdPool.get(rdKey);
		 if(aw.getCount()==0) {
			 return;
			 
		 }
		 else {
			 if(aw.getCount() <1) {
				 System.out.println(aw.getName()+"���ý����ѳ��ꡣ");
			 }
			 aw.setCount(aw.getCount() - 1);
			 System.out.println("�齱���:"+aw.getName());
		 }
	 }
	 public void showSurplus() {
		 Iterator<Awards> itor;
		 itor = rwdPool.values().iterator();
		 while(itor.hasNext()) {
			 Awards aw = itor.next();
			 System.out.println(aw.getName() + ";ʣ�ཱ��������" + aw.getCount());
		 }
	  }
	 
}



