
public class GenericCalculator{
	public static<T extends Number> double add(T t1,T t2) {
		Double n1 = Double.parseDouble(t1.toString());
        Double n2 = Double.parseDouble(t2.toString());
		return n1+n2 ;
		                                                   
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=3;
		int b=4;
		System.out.println("������:"+add(a,b));
		float c=3.0f;
		float d=7.0f;
		System.out.println("��������:"+add(c,d));
		
		double e=99.0;
		double f=1.0;
		System.out.println("˫���ȸ�������:"+add(e,f));
		long g=300;
		long h=700;
		System.out.println("��������:"+add(g,h));
	}

}
