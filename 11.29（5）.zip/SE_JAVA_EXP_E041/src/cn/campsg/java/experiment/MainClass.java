package cn.campsg.java.experiment;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import cn.campsg.java.experiment.entity.Trainee;
import cn.campsg.java.experiment.entity.TraineesGroups;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TraineesGroups tg = new TraineesGroups();
		ArrayList<Trainee> tt=new ArrayList<Trainee>();
		for(int i=0;i<5;i++) {
			Trainee e=new Trainee("ѧ��"+i,"male",172.5f-i);
			tt.add(e);
		}
		for(int i=0;i<5;i++) {
			Trainee e=new Trainee("ѧ��"+2*i,"famale",162.5f-i);
			tt.add(e);
		}
		tg.initTrainees(tt);
		Map<String, List<Trainee>> group = tg.groupTrainees();
		for(int i=0;i<group.get("male").size();i++) {
			System.out.println("����:"+group.get("male").get(i).getName()+"����:"+group.get("male").get(i).getHeight()+"�Ա�:"+group.get("male").get(i).getSex());
		}
		for(int i=0;i<group.get("female").size();i++) {
			System.out.println("����:"+group.get("female").get(i).getName()+"����:"+group.get("female").get(i).getHeight()+"�Ա�:"+group.get("female").get(i).getSex());
		}
	}

}
