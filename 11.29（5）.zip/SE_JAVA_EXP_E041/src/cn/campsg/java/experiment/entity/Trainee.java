package cn.campsg.java.experiment.entity;

public  class Trainee implements Comparable <Trainee> {
	public Trainee() {
		super();
	}
	public Trainee(String name, String sex, float height) {
		super();
		this.name = name;
		this.sex = sex;
		this.height = height;
	}
	private String name;
	private String sex;
	private float height;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}

	public int compareTo(Trainee anthor) {
		// TODO Auto-generated method stub
		return Float.compare(this.height, anthor.height);
	}

}
