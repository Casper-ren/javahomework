
public class SplitArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="2008/09/10";
		String newstr[]=new String[3];
		newstr=str.split("/");
		for(int i=0;i<newstr.length;i++)
		{
			System.out.println(newstr[i]);
		}
	}

}
