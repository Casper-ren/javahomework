package cn.campsg.java.experiment.util;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import cn.campsg.java.experiment.dao.EmployeeDao;
/**
 * 创建文件读取对象的控制器
 */
public class BeanManager {

	private static EmployeeDao employeeDao;
	
	private static Properties prop;
	//使用静态代码块，加载properties文件，实例化prop
	static {
		try {
			prop = new Properties();
			InputStream in = new BufferedInputStream(
					new FileInputStream(
							"conf/bean.properties"));
			prop.load(in);
		} catch (Exception e) {
			prop = null;
		}
	}

	/**
	 * 通过反射动态创建文件读取对象
	 * @return 返回实例化后的EmployeeDao
	 * @throws IOException
	 */
	public static EmployeeDao getDaoBean() throws IOException {
		
		if (prop == null)
			throw new IOException("无法加载bean.properties");

		if (employeeDao != null)
			return employeeDao;
		
		//获得配置文件中配置的dao层的类名
		String className = prop.getProperty("ClassName");
		try {
			//通过反射实例化EmployeeDao接口
			employeeDao = (EmployeeDao) Class.forName(className).newInstance();
			return employeeDao;
		} catch (Exception e) {
			throw new IOException("无法创建EmployeeDao，配置文件或类不存在。");
		}
	}
}
