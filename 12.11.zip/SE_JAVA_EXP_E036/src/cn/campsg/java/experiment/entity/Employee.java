package cn.campsg.java.experiment.entity;
/**
 * 员工实体类
 */
public class Employee {
	
	private String name;//姓名
	private String gender;//性别
	
	public Employee() {}
	
	public Employee(String name, String gender) {
		this.name = name;
		this.gender = gender;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", gender=" + gender + "]";
	}
	
}
