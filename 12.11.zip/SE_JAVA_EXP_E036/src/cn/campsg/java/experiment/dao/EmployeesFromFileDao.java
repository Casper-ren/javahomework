package cn.campsg.java.experiment.dao;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import cn.campsg.java.experiment.entity.Employee;
/**
 * 从文件中读取员工数据的实现类
 */
public class EmployeesFromFileDao implements EmployeeDao{
	
	//数据文件路径
	private final String FILE_PATH = "resource/emp.txt";

	public EmployeesFromFileDao() {}

	/**
	 * 从文本文档中读取所有的员工信息
	 * @return 返回所有员工组成的对象数组
	 * @throws IOException
	 */
	public Employee[] getEmployees() throws IOException {
		InputStream in = new FileInputStream(new File(FILE_PATH));
		//保存的文件格式为UTF-8,因此要用utf-8格式将字节流转换成字符流
		InputStreamReader reader = new InputStreamReader(in, "utf-8");
		BufferedReader bufferedReader = new BufferedReader(reader);
		String s=null;
		StringBuffer sb = new StringBuffer();
		while((s=bufferedReader.readLine()) != null) {
			sb.append(s);
			sb.append("@");
		}
		//关闭流
		bufferedReader.close();
		String str = sb.toString();
		//分割出数据字段
		String[] strs = str.split("@");
		
		Employee[] emps = new Employee[strs.length];
		for(int i=0; i<strs.length; i++) {
			//读取两个字段，封装成对象
			String[] datas = strs[i].split(",");
			emps[i] = new Employee(datas[0], datas[1]);
		}
		
		return emps;
	}
	
}
