package cn.campsg.java.experiment.dao;

import java.io.IOException;

import cn.campsg.java.experiment.entity.Employee;

/**
 * 员工操作的接口类
 */
public interface EmployeeDao {
	 public Employee[] getEmployees() throws IOException;
}
