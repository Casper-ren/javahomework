package cn.campsg.java.experiment.dao;

import java.io.File;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import cn.campsg.java.experiment.entity.Employee;
/**
 * 从excel中读取员工数据的实现类
 */
public class EmployeesFromExcelDao implements EmployeeDao{
	//数据文件路径
	private final String FILE_PATH = "resource/emp.xls";
	
	//数据文件所在的工作簿名称
	private final String SHEET_NAME = "Sheet1";
	
	public EmployeesFromExcelDao() {}
	
	/**
	 * 从excel中读取所有的员工信息
	 * @return 返回所有员工组成的对象数组
	 * @throws IOException
	 */
	public Employee[] getEmployees() throws IOException {
		Employee[] emps = null;
		
		try {
			//1.打开excel
			Workbook workbook = WorkbookFactory.create(new File(FILE_PATH));
			//2.打开excel里的工作簿
			Sheet sheet = workbook.getSheet(SHEET_NAME);
			//3.获得表里的记录的总行数
			int rowCount = sheet.getLastRowNum();
			//4.实例化对象数组的大小
			emps = new Employee[rowCount];
			//读取员工数据,第一行为列名， 因此i从1开始
			for(int i=1; i<=rowCount; i++) {
				//获得excel的一行
				Row row = sheet.getRow(i);
				//读取第一列的姓名
				String name = row.getCell(0).getStringCellValue();
				//读取第二列的性别
				String gender = row.getCell(1).getStringCellValue();
				//调用构造方法，封装成对象
				Employee e = new Employee(name, gender);
				//放入数组中，i从1开始的，所以要i-1
				emps[i-1] = e;
			}
			//关闭excel
			workbook.close();
		} catch (EncryptedDocumentException e) {
			throw new IOException();
		} catch (InvalidFormatException e) {
			throw new IOException();
		}
		return emps;
	}
	
}
