package cn.campsg.java.experiment;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

import cn.campsg.java.experiment.dao.EmployeeDao;
import cn.campsg.java.experiment.dao.EmployeesFromFileDao;
import cn.campsg.java.experiment.entity.Employee;
/**
 * 图表界面类
 */
public class StatisticView {

	public JFrame frame;
	
	/**
	 * 获得员工性别的统计结果(需要学生体验接口的特性）
	 * 
	 * @return 返回男，女员工的统计结果
	 * @throws IOException 文件读取失败
	 */
	public int[] getEmployeeStatistic() throws IOException {
		EmployeesFromFileDao a=new EmployeesFromFileDao();
		Employee[]employees=a.getEmployees();
		int man=0;
		int woman=0;
		for(int t=0;t<employees.length;t++) {
			if(employees[t].getGender()=="男") {
				man++;
			}
			else if(employees[t].getGender()=="女"){
				woman++;
			}
		}
		int bb[]=new int[2];
		bb[0]=man;
		bb[1]=woman;
		return bb;
	}

	/**
	 * Create the application.
	 */
	public StatisticView() {
		initialize();
		setCenter(frame);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		//创建窗口和视图容器
		frame = new JFrame();
		frame.setBounds(100, 100, 1027, 762);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		//创建主题样式
		StandardChartTheme sct = new StandardChartTheme("CN");
		//设置标题字体
		sct.setExtraLargeFont(new Font("黑体", Font.BOLD, 20));
		//设置轴向的字体
		sct.setLargeFont(new Font("黑体",Font.PLAIN, 15));
		//设置图例的字体
		sct.setRegularFont(new Font("黑体",Font.PLAIN, 15));
		//应用字体设置
		ChartFactory.setChartTheme(sct);
		//设置图表
		JFreeChart pieChart = ChartFactory.createPieChart("职工性别统计图", getDataset(), true, true, false);
		//显示数据的详细信息：{0}选项，{1}具体数值，{2}百分比
		PiePlot plot = (PiePlot) pieChart.getPlot();
		plot.setLabelGenerator(new StandardPieSectionLabelGenerator("{0}:{1}人({2})"));
		//把图表对象包装成ChartPanel，以便加入JPanel中
		ChartPanel cp = new ChartPanel(pieChart);
		panel.add(cp);
		
	}
	
	/**
	 * 获取学生性别比率数据
	 * 
	 * @return JFreeChart的数据集
	 */
	private DefaultPieDataset getDataset() {
		//获得员工性别的统计结果(需要学生体验接口的特性）
		//创建数据源对象
		DefaultPieDataset dpd = new DefaultPieDataset();
		//设置数据
		int[] statistic = null;
		//获取统计结果，并处理异常
		try {
			statistic = getEmployeeStatistic();
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		
		if(statistic != null && statistic.length == 2) {
			//将统计结果设置到图表上
			dpd.setValue("男", statistic[0]);
			dpd.setValue("女", statistic[1]);
		}
		
		return dpd;
	}
	
	/**
	 * 窗体自动居中 (代码临摹)
	 * 
	 * @param window
	 */
	private void setCenter(JFrame window) {
		// 获取屏幕的大小
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int width = window.getWidth();
		int height = window.getHeight();
		// 居中显示
		window.setBounds((d.width - width) / 2, (d.height - height) / 2, width,
				height);

	}
	
}
